package com.djtasty.teacollection;

public interface TeaDao {
}
